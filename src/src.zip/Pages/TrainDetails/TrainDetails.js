const TrainDetails = () => {
    return (
        <div>
            <h1> Train Details </h1>
        </div>
    )
}

export default TrainDetails 